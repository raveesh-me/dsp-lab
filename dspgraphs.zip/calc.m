k=0:15
x=1 + exp(-j*pi/8*k) + exp(-j*pi/8*k*2) + exp(-j*pi/8*k*3)
y=abs(x)